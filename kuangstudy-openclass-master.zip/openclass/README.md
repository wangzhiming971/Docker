# Bilibili狂神说Java公开课系列

**拒绝白嫖，记得收藏，三连**

QQ：24736743  微信公众号：狂神说

bilibili：狂神说 Java

视频地址：https://space.bilibili.com/95256449

**更新日志：**

- 2.16  更新JUC并发编程系列 https://www.bilibili.com/video/av90007319
- 3.19  更新 MyBatisPlus教程 https://www.bilibili.com/video/av97733494
- 3.20  更新了 Git教程 https://www.bilibili.com/video/av98007542
- 3.24  更新了 Linux 教程 https://www.bilibili.com/video/BV187411y7hF
- 4.01  更新了 Redis 教程 https://www.bilibili.com/video/BV1S54y1R7SB
- 4.07  更新了 ElasticSearch 教程 https://www.bilibili.com/video/BV17a4y1x7zq
- 4.22  更新了 POI&easyExcel 教程 https://www.bilibili.com/video/BV1Ua4y1x7BK
- 5.01  更新了 阿里云短信业务 教程 https://www.bilibili.com/video/BV1c64y1M7qN
- 5.08  更新了 Ngrok 的教程 https://www.bilibili.com/video/BV17K4y187A2
- 5.15  更新了 Docker 的教程 https://www.bilibili.com/video/BV1og4y1q7M4
- 6.11  更新了CI/CD 的教程 https://www.bilibili.com/video/BV1zf4y127vu
- 6.23 更新了 汇编先导课 教程，资料以上传码云

### B站主页：

![B站主页](https://images.gitee.com/uploads/images/2020/0322/130928_362ce918_2287834.png "QQ截图20200322130924.png")

### 这次一定！


![赞赏](https://images.gitee.com/uploads/images/2020/0322/131035_d434c4ed_2287834.jpeg "赞赏码.jpg")